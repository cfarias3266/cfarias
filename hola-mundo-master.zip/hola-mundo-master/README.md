## Ejemplo Hola Mundo en React JS

## Iniciar la aplicación (local)
Requerimientos:
* [Node](https://nodejs.org/)

Instalar las dependencias:
```
npm install
```

Inicar el servidor local
```
npm start
```
