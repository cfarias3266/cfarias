import React from 'react';

export default class Hola extends React.Component {
  render() {
    return (
      <h1>Hola Mundo en React</h1>
    );
  }
}
