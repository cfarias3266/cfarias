import React from 'react';
import {render} from 'react-dom';
import Hola from './Hola';

render(<Hola />, document.getElementById('root'));
